# Using 'puts' display the result of the following (true or false)
puts "Is it true 2 less than 5? It is ", 2 < 5
