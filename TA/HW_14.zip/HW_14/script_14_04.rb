# Using 'puts' display the following statement and its result
puts "What is 5 - 7?"
print "5 - 7 is "
puts 5 - 7
