# Using 'print' display how many Hans
print "25 + 30 / 6 "
print "Hans - "
print 25 + 30 / 6
