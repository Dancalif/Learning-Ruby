# Using 'puts' display the result of the following (true of false)
puts "Is it true 5 greater than 10?".chomp
print "It is "
puts 5 > 10
