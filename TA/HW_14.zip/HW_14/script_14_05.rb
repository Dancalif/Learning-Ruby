# Using 'puts' display the following statement and its result
puts "What is 11 times 6?"
print "11 times 6 is "
puts 11 * 6
