# Using 'print' display how many Roosters
print "100 - 25 * 3 % 4 "
print "Roosters - "
print 100 - 25 * 3 % 4
