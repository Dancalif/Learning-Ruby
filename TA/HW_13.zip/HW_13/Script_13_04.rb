# Script where \n was used

puts "This is a multiline statement\n using puts\nfor each line!"
