# Double quotes and backslash together

puts "This statement contains \" double\ quote"
