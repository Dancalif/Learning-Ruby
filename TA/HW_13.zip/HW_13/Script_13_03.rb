# Each puts should create new line.

puts "This is a multiline statement"
puts "using puts"
puts "for each line!"
