# Script with quotes and backslash

puts "This statement contains \" double\ quote"
