# Output should be Hello World! with new line
puts "Hello World!"