# Script to measure the lenght of the string

puts "This statement contains ", "This statement contains \" double\ quote".length, "chars."
