# Script with backslash.

puts "This statement\ contains \\ backslash"
