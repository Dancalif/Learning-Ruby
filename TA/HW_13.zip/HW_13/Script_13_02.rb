# Output should be Hello World
print "Hello World"