# Script with Here doc

puts <<EOF
This is a multiline statement\n    using puts\n for each line!
EOF