# Multiplication in string.

puts "This statement it repeat itself twice! "*2
