#Display 'object_id' result of the comparison using '.equal?' operator of the strings and symbols.


result = :qa.object_id
puts result

result = :qa.object_id
puts result

result = :qa.object_id
puts result

result = :qa.object_id
puts result