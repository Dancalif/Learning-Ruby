#Display result of the comparison using '.eql?'operator.

result = 1.eql?(1)
puts result

result = 1.eql?(1.0)
puts result

result = "qa".eql?("qa")
puts result

