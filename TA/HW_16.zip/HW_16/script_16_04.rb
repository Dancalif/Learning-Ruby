#Display result of the comparison using '<' operator of the 'a' and 'b' variables.

a = 10
b = 3

result = a < b
puts result