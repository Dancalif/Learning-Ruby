# Creating method with parametr.

def my_method_param (name)
	puts "Hello #{name}!"
end

# Method Call

my_method_param ("Dan")
