def calc_sum_two(first, second)
	puts "Summary of both values is #{first + second}"
end

# Call the method.

calc_sum_two(5, 17)

