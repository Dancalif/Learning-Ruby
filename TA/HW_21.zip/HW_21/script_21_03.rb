# Creating method with parametr and default.

def my_method_param_default (name = "Dan")
	puts "Privet #{name}!"
end

# Method Call

my_method_param_default

my_method_param_default ("Ruby")
