# Creating method.

def my_method
    
	name = "Dan"
	puts "Hello #{name}!"

end

# Method Call

my_method
