# Display the result of the addition operation using variables a and b.

a = 10
b = 3
result = "a + b is", a + b
puts result