#Display result of the modulus operation using variables 'a' and 'b'.

a = 10
b = 3

result=a%b
puts result
