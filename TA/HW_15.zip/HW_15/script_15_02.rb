#Display result of the subtraction operation using variabgles a and b:

a = 10
b = 3

result = "a - b is", a - b
puts result