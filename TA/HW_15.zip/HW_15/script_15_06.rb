#Display rersult of the exponent operation.

a = 10
b = 3

result=a**b
puts result
