# Display result of the multiplication operation using the variables a and b:

a = 10
b = 3

result = "a * b is", a * b
puts result