#Display result of the assignment unsing '=' of the variables ''c=a+b'

a = 10
b = 3


c = a + b

puts c