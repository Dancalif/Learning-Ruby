#Display result of the assignment using '+=' of the variables 'c+=a'


a = 10
b = 3
c ||=1

c += a

puts c