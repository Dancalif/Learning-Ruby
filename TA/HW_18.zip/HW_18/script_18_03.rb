#Display result both conditions of the logical operator '&&' using the 'a' and 'b' variables

a = 10
b = 3

if a == 10 && b == 3
puts "Correct"
else 
puts "Incorrect"
end

if a == 3 && b == 10
puts "Correct"
else 
puts "Incorrect"
end

if a == 5 && b == 3
puts "Correct"
else 
puts "Incorrect"
end