#Display result both conditions of the logical operator 'and' using the 'a' and 'b' variables

a = 10
b = 3

if a ==10 and b == 3
puts "Correct"
else
puts "Incorrect"
end

a = 10
b = 3

if a ==10 and b ==5
puts "Corrent"
else 
puts "Incorrect"
end