#Display result both conditions of the logical operator 'not' using the 'a' and 'b' variables

a = 10

if not(a&&5)
puts "Correct"
else
puts "Incorrect"
end

a = 10

if not(a&&10)
puts "Correct"
else
puts "Incorrect"
end

