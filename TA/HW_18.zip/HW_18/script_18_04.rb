#Display result both conditions of the logical operator '||' using the 'a' and 'b' variables


a = 10
b = 3

if a == 10 || b == 3
puts "Correct"
else
puts "Incorrect"
end

a = 10
b = 3

if a ==10 || b ==5
puts "Corrent"
else 
puts "Incorrect"
end


a = 10
b = 3

if a ==3 || b ==10
puts "Corrent"
else 
puts "Incorrect"
end
