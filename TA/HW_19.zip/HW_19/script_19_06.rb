# Displaying the range from cab to cat

words = "cab".."cat"
print "Range is " , words , "\n"
print "Class is " , words.class , "\n"
print words.to_a
