# Score Ruby Program

score = 
result = case score
when 0..10 then "Fail"
when 11..20 then "Pass"
else "Invalid Score"
end
puts result

score = 5
result = case score
when 0..10 then "Fail"
when 11..20 then "Pass"
else "Invalid Score"
end
puts result

score = 15
result = case score
when 0..10 then "Fail"
when 11..20 then "Pass"
else "Invalid Score"
end
puts result