# Displaying if caw includes to array

words=("cab".."cat")
print "Is caw in array\: "
print words.to_a.include? "caw"
