# Displaying if cap includes to array

words=("cab".."cat")
print "Is cap in array\: "
print words.to_a.include? "cap"
