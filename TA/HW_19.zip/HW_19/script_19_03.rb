# Displaying the minimum item in the range from 1 to 768

numbers = 1..768
print "Range is " , numbers , "\n"
print "Class is " , numbers.class , "\n"
print "Minimum item is " , numbers.min

