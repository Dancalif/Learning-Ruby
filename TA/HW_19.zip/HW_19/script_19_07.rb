# Displaying the size in the range from cab to cat

words = "cab".."cat"
print "The size is " , words.to_a.size
