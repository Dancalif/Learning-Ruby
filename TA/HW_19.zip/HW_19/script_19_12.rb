# Displaying the size of the range from a to z

words=("a".."z")
print "The size is " , words.to_a.size
