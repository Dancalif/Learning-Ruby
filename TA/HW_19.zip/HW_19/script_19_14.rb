# Displaying the size of the range from aaa to zzz

letters = ("aaa".."zzz")
print "The size is " , letters.to_a.size
