# Displaying the maximum item in the range from 1 to 768

numbers = 1..768
print "Range is " , numbers , "\n"
print "Class is " , numbers.class , "\n"
print "Maximum item is " , numbers.max

