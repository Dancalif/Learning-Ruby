# Displaying the size of the range from aa to zz

letters = ("aa".."zz")
print "The size is " , letters.to_a.size
