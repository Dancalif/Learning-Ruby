# Displaying the range from a to z

letters = "a".."z"
print "Range is " , letters , "\n"
print "Class is " , letters.class , "\n"
print letters.to_a

