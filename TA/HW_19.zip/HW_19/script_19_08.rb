# Displaying the first item in the range from cab to cat

words = "cab".."cat"
print "The first item is " , words.to_a.first
