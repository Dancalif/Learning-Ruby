# Displaying the last item in the range from cab to cat

words = "cab".."cat"
print "The last item is " , words.to_a.last
