# Displaying the range from 1 to 10

numbers = 1...10
puts numbers
puts numbers.class
puts numbers.to_a
print numbers.to_a